/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicioentidades;

import entidades.Mes;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Marcelino
 */
public class ServicioMes {

    Scanner leer = new Scanner(System.in);

    public Mes CrearObjeto() {
        Mes m1 = new Mes();
        String aux[] = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"};
        m1.setV(aux);
        int numero = (int) (Math.random() * 12);
        String mesS = m1.getV()[numero];
        m1.setMessecreto(mesS);
        return m1;

    }
public void adivinar(Mes m1){
    boolean respuesta=false;
   System.out.println("Ingrese un mes");
    String mesingresado=leer.nextLine().toLowerCase();
do{
    if (m1.getMessecreto().equals(mesingresado)) {
        respuesta=true;
    }else{
       System.out.println("Ingrese nuevamente el mes ");
        mesingresado=leer.nextLine().toLowerCase();
    } 
} while(respuesta==false);
    if (respuesta==true) {
        System.out.println("adivino el mes secreto");
    }
   
    
}

}
