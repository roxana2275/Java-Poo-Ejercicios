/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import entidades.EntidadMatemat;

/**
 *
 * @author A278617
 */
public class ServiciosMat {
    
    public static double devolverMayor(EntidadMatemat m1){
        double numMayor;
        if (m1.getNum1()>m1.getNum2()){
            numMayor=m1.getNum1();           
        }else{
            numMayor=m1.getNum2();
        }
        return numMayor;
    }
    
     public static double devolverMenor(EntidadMatemat m1){
        double numMenor;
        if (m1.getNum1()>m1.getNum2()){
            numMenor=m1.getNum2();           
        }else{
            numMenor=m1.getNum1();
        }
        return numMenor;
    }
 
    public int calcularPotencia(EntidadMatemat m1){
        int Mayor =(int) devolverMayor(m1);
        int Menor = (int) devolverMenor(m1);
        int potencia = (int) Math.pow(Mayor,Menor);
        return potencia;
        
    }
    
    public double calcularRaiz(EntidadMatemat m1){
        int absoluto = (int) Math.abs(devolverMenor(m1));
        double raiz = Math.sqrt(absoluto);
        return raiz;
        
    }
        
    
}
