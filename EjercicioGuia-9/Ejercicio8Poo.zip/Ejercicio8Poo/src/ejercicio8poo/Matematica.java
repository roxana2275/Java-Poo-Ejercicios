/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio8poo;

import entidades.EntidadMatemat;
import servicios.ServiciosMat;
import static servicios.ServiciosMat.devolverMayor;
import static servicios.ServiciosMat.devolverMenor;

/**
 *
 * @author A278617
 */
public class Matematica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServiciosMat ms = new ServiciosMat();
        EntidadMatemat m1 = new EntidadMatemat();
        m1.setNum1(Math.random()*10);
        m1.setNum2(Math.random()*10);
        System.out.println("el primer num es " +m1.getNum1());
        System.out.println("el segundo num es " +m1.getNum2());
        System.out.println("el num mayor ingresado es " + devolverMayor(m1));
        System.out.println("el num menor ingresado es " + devolverMenor(m1));
        System.out.println("la potencia del núm es " +ms.calcularPotencia(m1));
        System.out.println("la raiz del núm es " +ms.calcularRaiz(m1));

        
    }
    
}
