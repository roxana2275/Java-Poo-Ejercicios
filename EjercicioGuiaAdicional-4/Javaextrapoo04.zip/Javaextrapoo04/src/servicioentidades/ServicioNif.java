/*
 * Dígito Verificador. Crear una clase NIF que se usará para mantener DNIs con su
correspondiente letra (NIF). Los atributos serán el número de DNI (entero largo) y la
letra (String o char) que le corresponde. Dispondrá de los siguientes métodos:
 Métodos getters y setters para el número de DNI y la letra.
 Método crearNif(): le pide al usuario el DNI y con ese DNI calcula la letra que le
corresponderá. Una vez calculado, le asigna la letra que le corresponde según el
resultado del calculo.
 Método mostrar(): que nos permita mostrar el NIF (ocho dígitos, un guion y la letra
en mayúscula; por ejemplo: 00395469-F).
La letra correspondiente al dígito verificador se calculará a traves de un método que
funciona de la siguiente manera: Para calcular la letra se toma el resto de dividir el
número de DNI por 23 (el resultado debe ser un número entre 0 y 22). El método debe
buscar en un array (vector) de caracteres la posición que corresponda al resto de la
división para obtener la letra correspondiente. La tabla de caracteres es la siguiente:
 */
package servicioentidades;

import entidades.Nif;
import java.util.Scanner;

/**
 *
 * @author Marcelino
 */
public class ServicioNif {

    Scanner leer = new Scanner(System.in);

    public Nif crearNif() {
        Nif n = new Nif();
        System.out.println("Ingrese el numero de Dni");
        n.setDNI(leer.nextLong());
        int modulo = (int) n.getDNI() % 23;
        String v[] = new String[22];
        
        String aux="TRWAGMYFPDXBNJZSQVHLCKE";
        
        for (int i = 0; i < v.length; i++) {
            v[i]=aux.substring(i,i+1);
            
        }
        n.setNif(v[modulo]);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

//        switch (modulo) {
//            case 0:
//                n.setNif("T");
//                break;
//            case 1:
//                n.setNif("R");
//                break;
//            case 2:
//                n.setNif("W");
//                break;
//            case 3:
//                n.setNif("A");
//                break;
//            case 4:
//                n.setNif("G");
//                break;
//
//            case 5:
//                n.setNif("M");
//                break;
//
//            case 6:
//                n.setNif("Y");
//                break;
//
//            case 7:
//                n.setNif("F");
//                break;
//
//            case 8:
//                n.setNif("P");
//                break;
//
//            case 9:
//                n.setNif("D");
//                break;
//
//            case 10:
//                n.setNif("X");
//                break;
//
//            case 11:
//                n.setNif("B");
//                break;
//
//            case 12:
//                n.setNif("N");
//                break;
//
//            case 13:
//                n.setNif("J");
//                break;
//
//            case 14:
//                n.setNif("Z");
//                break;
//
//            case 15:
//                n.setNif("S");
//                break;
//
//            case 16:
//                n.setNif("Q");
//                break;
//
//            case 17:
//                n.setNif("V");
//                break;
//
//            case 18:
//                n.setNif("H");
//                break;
//
//            case 19:
//                n.setNif("L");
//                break;
//
//            case 20:
//                n.setNif("C");
//                break;
//
//            case 21:
//                n.setNif("K");
//                break;
//
//            case 22:
//                n.setNif("E");
//                break;
//
//        }
        return n;
    }

    public void mostrar(Nif n) {

        System.out.println(String.format("%08d", n.getDNI()) + "-" + n.getNif());

    }
}
