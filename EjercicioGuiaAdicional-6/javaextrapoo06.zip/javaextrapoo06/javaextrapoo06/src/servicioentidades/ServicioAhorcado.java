/*
 * Juego Ahorcado: Crear una clase Ahorcado (como el juego), la cual deberá contener
como atributos, un vector con la palabra a buscar, la cantidad de letras encontradas y la
cantidad jugadas máximas que puede realizar el usuario. Definir los siguientes métodos
con los parámetros que sean necesarios:
 Constructores, tanto el vacío como el parametrizado.
 Metodo crearJuego(): le pide la palabra al usuario y cantidad de jugadas máxima.
Con la palabra del usuario, pone la longitud de la palabra, como la longitud del
vector. Después ingresa la palabra en el vector, letra por letra, quedando cada letra
de la palabra en un índice del vector. Y también, guarda en cantidad de jugadas
máximas, el valor que ingresó el usuario y encontradas en 0.
 Método longitud(): muestra la longitud de la palabra que se debe encontrar. Nota:
buscar como se usa el vector.length.
 Método buscar(letra): este método recibe una letra dada por el usuario y busca sila
letra ingresada es parte de la palabra o no. También informará si la letra estaba o no.
 Método encontradas(letra): que reciba una letra ingresada por el usuario y muestre
cuantas letras han sido encontradas y cuantas le faltan. Este método además deberá
devolver true si la letra estaba y false si la letra no estaba, ya que, cada vez que se
busque una letra que no esté, se le restará uno a sus oportunidades.
 Método intentos(): para mostrar cuantas oportunidades le queda al jugador.
 Método juego(): el método juego se encargará de llamar todos los métodos
previamente mencionados e informará cuando el usuario descubra toda la palabra o
se quede sin intentos. Este método se llamará en el main.

Un ejemplo de salida puede ser así:

Ingrese una letra:
a
Longitud de la palabra: 6
Mensaje: La letra pertenece a la palabra
Número de letras (encontradas, faltantes): (3,4)
Número de oportunidades restantes: 4
----------------------------------------------
Ingrese una letra:
z
Longitud de la palabra: 6
Mensaje: La letra no pertenece a la palabra
Número de letras (encontradas, faltantes): (3,4)
Número de oportunidades restantes: 3
---------------------------------------------
Ingrese una letra:
b
Longitud de la palabra: 6
Mensaje: La letra no pertenece a la palabra
Número de letras (encontradas, faltantes): (4,3)
Número de oportunidades restantes: 2
----------------------------------------------
Ingrese una letra:
u
Longitud de la palabra: 6
Mensaje: La letra no pertenece a la palabra
Número de letras (encontradas, faltantes): (4,3)
Número de oportunidades restantes: 1
----------------------------------------------
Ingrese una letra:

q
Longitud de la palabra: 6
Mensaje: La letra no pertenece a la palabra
Mensaje: Lo sentimos, no hay más oportunidades
 */
package servicioentidades;

import entidades.Ahorcado;
import java.util.Scanner;

/**
 *
 * @author Marcelino
 */
public class ServicioAhorcado {

    Scanner leer = new Scanner(System.in);

    public Ahorcado CrearJuego() {
        Ahorcado a = new Ahorcado();
        System.out.println("Ingrese la palabra");
        String palabra = leer.next();
        a.setLongitud(palabra.length());
        String vector1[] = new String[palabra.length()];
        for (int i = 0; i < palabra.length(); i++) {
            vector1[i] = palabra.substring(i, i + 1);

        }
        a.setVector(vector1);
        System.out.println("Ingrese la cantidad maxima de jugadas");
        a.setJugadasMax(leer.nextInt());
        a.setLetrasEncontradas(0);
        return a;
    }

    public int longitud(Ahorcado a) {
        int longVector = a.getVector().length;
        return longVector;
    }

    public boolean buscar(String letraBuscar, Ahorcado a) {
        boolean estaba = false;
        String aux[]=new String[a.getLongitud()];
        aux=a.getVector();
       
        if(letraBuscar.equalsIgnoreCase("*") ){
            System.out.println("Opción no valida");
        } else {

            for (int i = 0; i < longitud(a); i++) {
                if (letraBuscar.equalsIgnoreCase(a.getVector()[i])) {
                    System.out.println("la letra se encuenta en la palabra ");
                    aux[i] = "*";
                    estaba = true;
                } else {
                    System.out.println("No se encuentra la letra en la palabra ");
                    estaba = false;
                    int prueba = a.getJugadasMax() - 1;

                    a.setJugadasMax(a.getJugadasMax() - 1);
                    

                }

            }
        }
        a.setVector(aux);
        return estaba;
    }

    public void encontradas(String letra, Ahorcado a) {
        boolean estaba;
        System.out.println("la cantidad de letras encontradas es: " + a.getLetrasEncontradas());
        intentos(a);
        buscar(letra, a);
    }

    public void intentos(Ahorcado a) {

        System.out.println(" Le faltan " + (a.getLongitud() - a.getLetrasEncontradas()));

    }

    public void palabrasUsadas() {

    }
}
