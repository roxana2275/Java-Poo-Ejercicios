/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

/**
 *
 * @author Equipo
 */
public class Cadena {
    private String frase;
    private int Longitud;

    public Cadena() {
    }

    public Cadena(String frase, int Longitud) {
        this.frase = frase;
        this.Longitud = Longitud;
    }

    public String getFrase() {
        return frase;
    }

    public void setFrase(String frase) {
        this.frase = frase;
    }

    public int getLongitud() {
        return Longitud = frase.length();
    }

    public void setLongitud(int Longitud) {
        this.Longitud = Longitud;
    }
    
    
    
    
    
    
    
    
    
    
}
