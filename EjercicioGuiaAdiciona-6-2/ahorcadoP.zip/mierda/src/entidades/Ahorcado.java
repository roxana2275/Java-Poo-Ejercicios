
package entidades;



/**
 *
 * @author Marcelino
 */
public class Ahorcado {

   
    private String vector[] = {"perro", "libro", "fuego"}; //vector para random
    private String v[];//vector a compara
    private String usuario[];
    private int longitud, letrasEncontradas, jugadasMax;
    private String palabraSecreta;

    public Ahorcado() {
    }

    public Ahorcado(int longitud, int letrasEncontradas,String palabraSecreta) {
        this.longitud = longitud;
        this.letrasEncontradas = letrasEncontradas;
        this.palabraSecreta=palabraSecreta;
    }

    public Ahorcado(String[] v) {
        this.v = v;
    }

    public String[] getV() {
        return v;
    }

    public void setV(String[] v) {
        this.v = v;
    }

   

    public String[] getVector() {
        return vector;
    }

    public void setVector(String[] vector) {
        this.vector = vector;
    }

    public int getLongitud() {
        return longitud;
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }

    public int getLetrasEncontradas() {
        return letrasEncontradas;
    }

    public void setLetrasEncontradas(int letrasEncontradas) {
        this.letrasEncontradas = letrasEncontradas;
    }

    public int getJugadasMax() {
        return jugadasMax;
    }

    public void setJugadasMax(int jugadasMax) {
        this.jugadasMax = jugadasMax;
    }

    public String[] getUsuario() {
        return usuario;
    }

    public void setUsuario(String[] usuario) {
        this.usuario = usuario;
    }

    public String getPalabraSecreta() {
        return palabraSecreta;
    }

    public void setPalabraSecreta(String palabraSecreta) {
        this.palabraSecreta = palabraSecreta;
    }

    
}
