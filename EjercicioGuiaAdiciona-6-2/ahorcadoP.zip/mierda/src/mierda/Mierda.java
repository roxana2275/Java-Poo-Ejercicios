/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mierda;

import entidades.Ahorcado;
import java.util.Scanner;
import servicioentidades.ServicioAhorcado;

/**
 *
 * @author Marcelino
 */
public class Mierda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        ServicioAhorcado a = new ServicioAhorcado();
        Ahorcado i = a.CrearJuego();
        a.juegos(i);
    }

}
